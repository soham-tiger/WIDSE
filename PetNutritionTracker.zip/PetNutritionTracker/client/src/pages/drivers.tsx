import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Play, Calculator } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { DriverImpactChart } from "@/components/charts/driver-impact-chart";
import { GlobalFilters, defaultFilters, type GlobalFilters as FilterType } from "@/components/global-filters";

export default function Drivers() {
  const [priceChange, setPriceChange] = useState([0]);
  const [distributionChange, setDistributionChange] = useState([0]);
  const [marketingSpendChange, setMarketingSpendChange] = useState([0]);
  const [simulationResult, setSimulationResult] = useState<any>(null);
  const [filters, setFilters] = useState<FilterType>(defaultFilters);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const simulationMutation = useMutation({
    mutationFn: (params: any) => api.runSimulation(params),
    onSuccess: (data) => {
      setSimulationResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/simulations"] });
      toast({
        title: "Simulation Complete",
        description: "Scenario analysis has been completed successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Simulation Failed",
        description: "Unable to run simulation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const runSimulation = () => {
    const params = {
      priceChange: priceChange[0],
      distributionChange: distributionChange[0],
      marketingSpendChange: marketingSpendChange[0],
    };

    simulationMutation.mutate(params);
  };

  // Re-run simulation when filters change
  useEffect(() => {
    if (simulationResult) {
      runSimulation();
    }
  }, [filters]);

  const formatCurrency = (value: number) => `$${Math.round(value).toLocaleString()}`;
  const formatPercentage = (value: number) => `${value > 0 ? '+' : ''}${value}%`;

  return (
    <div>
      <Header
        title="Sales Drivers & Simulation"
        subtitle="Analyze and simulate key performance drivers"
        actionButton={{
          label: "Run Simulation",
          onClick: runSimulation,
          icon: <Play className="w-4 h-4 mr-2" />
        }}
      />

      <div className="p-8">
        {/* Global Filters */}
        <GlobalFilters 
          filters={filters} 
          onFiltersChange={setFilters} 
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Simulation Controls */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Scenario Parameters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Price Adjustment */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Price Change: {formatPercentage(priceChange[0])}
                  </Label>
                  <Slider
                    value={priceChange}
                    onValueChange={setPriceChange}
                    min={-20}
                    max={20}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>-20%</span>
                    <span>+20%</span>
                  </div>
                </div>

                {/* Distribution Change */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Distribution Change: {formatPercentage(distributionChange[0])}
                  </Label>
                  <Slider
                    value={distributionChange}
                    onValueChange={setDistributionChange}
                    min={-15}
                    max={15}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>-15%</span>
                    <span>+15%</span>
                  </div>
                </div>



                {/* Marketing Spend */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Marketing Spend Increase: {formatPercentage(marketingSpendChange[0])}
                  </Label>
                  <Slider
                    value={marketingSpendChange}
                    onValueChange={setMarketingSpendChange}
                    min={0}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span>+50%</span>
                  </div>
                </div>

                <Button 
                  onClick={runSimulation} 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={simulationMutation.isPending}
                >
                  <Calculator className="w-4 h-4 mr-2" />
                  {simulationMutation.isPending ? "Calculating..." : "Calculate Impact"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Simulation Results */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Projected Sales */}
              <Card>
                <CardHeader>
                  <CardTitle>Projected Sales Impact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Sales Value:</span>
                    <span className="font-semibold text-gray-900">
                      {simulationResult ? formatCurrency(simulationResult.projectedSalesValue) : "$168,000"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Units Sold:</span>
                    <span className="font-semibold text-gray-900">
                      {simulationResult ? simulationResult.projectedSalesUnits.toLocaleString() : "8,650"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Change vs Baseline:</span>
                    <span className={`font-semibold ${simulationResult?.incrementalRevenue > 0 ? 'text-green-600' : simulationResult?.incrementalRevenue < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                      {simulationResult ? 
                        `${simulationResult.incrementalRevenue > 0 ? '+' : ''}${formatCurrency(simulationResult.incrementalRevenue)}` : 
                        "+$0"
                      }
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* ROI Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle>ROI Analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Investment:</span>
                    <span className="font-semibold text-gray-900">
                      {simulationResult ? formatCurrency(simulationResult.investmentCost || 0) : "$0"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Incremental Revenue:</span>
                    <span className="font-semibold text-gray-900">
                      {simulationResult ? formatCurrency(simulationResult.incrementalRevenue) : "$0"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">ROI:</span>
                    <span className="font-semibold text-green-600">
                      {simulationResult ? `${simulationResult.roi}x` : "0.0x"}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Driver Impact Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Driver Impact Analysis</CardTitle>
                <p className="text-sm text-gray-500">Individual contribution of each driver to revenue impact</p>
              </CardHeader>
              <CardContent>
                <DriverImpactChart simulationData={simulationResult} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
