import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { ForecastChart } from "@/components/charts/forecast-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { GlobalFilters, defaultFilters, type GlobalFilters as FilterType } from "@/components/global-filters";
import { RefreshCw, Lightbulb, TrendingUp, AlertTriangle, Target, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Insights() {
  const [chatQuestion, setChatQuestion] = useState("");
  const [chatResponse, setChatResponse] = useState("");
  const [filters, setFilters] = useState<FilterType>(defaultFilters);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: insights, isLoading, refetch: refetchInsights } = useQuery({
    queryKey: ["/api/insights", filters],
    queryFn: api.getInsights,
  });

  const { data: nutritionData, refetch: refetchNutrition } = useQuery({
    queryKey: ["/api/nutrition-data", filters],
    queryFn: api.getNutritionData,
  });

  // Refetch data when filters change
  useEffect(() => {
    refetchInsights();
    refetchNutrition();
  }, [filters, refetchInsights, refetchNutrition]);

  const generateInsightsMutation = useMutation({
    mutationFn: api.generateInsights,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/insights"] });
      toast({
        title: "Insights Updated",
        description: "AI insights have been refreshed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Update Insights",
        description: "Unable to refresh insights. Please try again.",
        variant: "destructive",
      });
    },
  });

  const chatMutation = useMutation({
    mutationFn: (question: string) => api.askQuestion(question),
    onSuccess: (data) => {
      setChatResponse(data.answer);
    },
    onError: () => {
      setChatResponse("I'm unable to answer that question right now. Please try again.");
    },
  });

  const handleChatSubmit = () => {
    if (!chatQuestion.trim()) return;
    chatMutation.mutate(chatQuestion);
    setChatQuestion("");
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'growth':
        return <TrendingUp className="text-green-600" />;
      case 'risk':
        return <AlertTriangle className="text-red-600" />;
      case 'opportunity':
        return <Target className="text-blue-600" />;
      default:
        return <Lightbulb className="text-blue-600" />;
    }
  };

  const getInsightBadgeColor = (type: string) => {
    switch (type) {
      case 'growth':
        return 'bg-green-100 text-green-800';
      case 'risk':
        return 'bg-red-100 text-red-800';
      case 'opportunity':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading insights...</div>;
  }

  const data = nutritionData?.[0];

  return (
    <div>
      <Header
        title="AI-Powered Insights"
        subtitle="Automated analysis and recommendations"
        actionButton={{
          label: "Refresh Insights",
          onClick: () => generateInsightsMutation.mutate(),
          icon: <RefreshCw className="w-4 h-4 mr-2" />
        }}
      />

      <div className="p-8">
        {/* Global Filters */}
        <GlobalFilters 
          filters={filters} 
          onFiltersChange={setFilters} 
        />
        
        {/* Executive Summary */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl border border-blue-200 mb-8">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Lightbulb className="text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Executive Summary</h3>
              <p className="text-gray-700 leading-relaxed">
                Q1 2025 performance shows strong growth in sales value (+12.5%) driven primarily by price optimization. 
                However, customer penetration declined (-2.1%), indicating potential market saturation. 
                High-value customers continue to drive disproportionate revenue, representing 15% of customers but 38% of total value. 
                Immediate focus should be on customer acquisition and retention strategies.
              </p>
            </div>
          </div>
        </div>

        {/* Insight Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {insights?.map((insight) => (
            <Card key={insight.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                    {getInsightIcon(insight.type)}
                  </div>
                  <Badge className={getInsightBadgeColor(insight.type)}>
                    {insight.type.charAt(0).toUpperCase() + insight.type.slice(1)}
                  </Badge>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{insight.title}</h4>
                <p className="text-gray-700 text-sm mb-4">{insight.description}</p>
                <div className="flex items-center text-sm text-blue-600 font-medium">
                  <span className="mr-2">→</span>
                  {insight.recommendation}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recommendations Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Strategic Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle>Strategic Recommendations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs font-bold">1</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">Expand High-Performing SKUs</h4>
                  <p className="text-gray-700 text-sm mt-1">
                    Increase distribution of Adult Complete by 15% in underperforming regions. Est. impact: +$23K revenue.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg">
                <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs font-bold">2</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">Loyalty Program Enhancement</h4>
                  <p className="text-gray-700 text-sm mt-1">
                    Target high-value customers with premium loyalty tier. Projected retention increase: 18%.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-4 bg-purple-50 rounded-lg">
                <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs font-bold">3</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">Digital Marketing Focus</h4>
                  <p className="text-gray-700 text-sm mt-1">
                    Increase digital spend by 25% targeting pet parents aged 25-40. Expected customer acquisition: +1,200.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Forecast & Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Forecast & Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ForecastChart />
            </CardContent>
          </Card>
        </div>

        {/* AI Chat Interface */}
        <Card>
          <CardHeader>
            <CardTitle>Ask Our AI Analyst</CardTitle>
            <p className="text-gray-500 text-sm">Get instant answers about your data and performance</p>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4 mb-4">
              <Input
                value={chatQuestion}
                onChange={(e) => setChatQuestion(e.target.value)}
                placeholder="Ask a question about your pet nutrition performance..."
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && handleChatSubmit()}
              />
              <Button 
                onClick={handleChatSubmit}
                disabled={chatMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            {chatResponse && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-800">{chatResponse}</p>
              </div>
            )}

            <div className="text-sm text-gray-500 mt-4">
              Try asking: "Why did customer penetration decline?" or "What's driving the growth in Adult Complete?"
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
