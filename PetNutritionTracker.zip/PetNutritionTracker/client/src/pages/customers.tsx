import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { MetricCard } from "@/components/metric-card";
import { CustomerSegmentChart } from "@/components/charts/customer-segment-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GlobalFilters, defaultFilters, type GlobalFilters as FilterType } from "@/components/global-filters";
import { Users, Heart, DollarSign } from "lucide-react";

export default function Customers() {
  const [filters, setFilters] = useState<FilterType>(defaultFilters);
  
  const { data: nutritionData, isLoading: nutritionLoading, refetch: refetchNutrition } = useQuery({
    queryKey: ["/api/nutrition-data", filters],
    queryFn: api.getNutritionData,
  });

  const { data: customerSegments, isLoading: segmentsLoading, refetch: refetchSegments } = useQuery({
    queryKey: ["/api/customer-segments", filters],
    queryFn: api.getCustomerSegments,
  });

  // Refetch data when filters change
  useEffect(() => {
    refetchNutrition();
    refetchSegments();
  }, [filters, refetchNutrition, refetchSegments]);

  if (nutritionLoading || segmentsLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  const data = nutritionData?.[0];
  const segments = customerSegments || [];

  if (!data) {
    return <div className="flex items-center justify-center h-screen">No data available</div>;
  }

  const loyalCustomers = Math.round(data.customers * (data.loyalPenetrationPct / 100));

  // Transform segments for chart
  const chartSegments = segments.map(segment => ({
    name: segment.segmentName,
    percentage: (segment.customerCount / data.customers) * 100
  }));

  // Calculate frequency distribution
  const frequencyData = {
    labels: ['1x', '2x', '3x', '4x', '5x+'],
    values: [2200, 3100, 1800, 1200, 500] // Mock data based on segments
  };

  return (
    <div>
      <Header
        title="Customer Analytics"
        subtitle="Customer segmentation and behavioral insights"
      >
        <Select defaultValue="all-segments">
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-segments">All Segments</SelectItem>
            <SelectItem value="high-value">High-Value</SelectItem>
            <SelectItem value="loyal">Loyal</SelectItem>
            <SelectItem value="at-risk">At-Risk</SelectItem>
          </SelectContent>
        </Select>
      </Header>

      <div className="p-8">
        {/* Global Filters */}
        <GlobalFilters 
          filters={filters} 
          onFiltersChange={setFilters} 
        />
        
        {/* Customer Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <MetricCard
            title="Total Customers"
            value={data.customers.toLocaleString()}
            icon={<Users className="text-blue-600 text-lg" />}
            iconBgColor="bg-blue-100"
          />
          <MetricCard
            title="Loyal Customers"
            value={loyalCustomers.toLocaleString()}
            change={`${data.loyalPenetrationPct}% penetration`}
            changeType="positive"
            icon={<Heart className="text-green-600 text-lg" />}
            iconBgColor="bg-green-100"
          />
          <MetricCard
            title="Avg Spend per Customer"
            value={`$${data.spendPerCustomer}`}
            icon={<DollarSign className="text-purple-600 text-lg" />}
            iconBgColor="bg-purple-100"
          />
        </div>

        {/* Customer Segments and Behavior */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Customer Segmentation */}
          <Card>
            <CardHeader>
              <CardTitle>Customer Segmentation</CardTitle>
            </CardHeader>
            <CardContent>
              <CustomerSegmentChart segments={chartSegments} />
            </CardContent>
          </Card>

          {/* Purchase Frequency */}
          <Card>
            <CardHeader>
              <CardTitle>Purchase Frequency Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {frequencyData.labels.map((label, index) => (
                  <div key={label} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{label} per quarter</span>
                    <div className="flex items-center space-x-2">
                      <div 
                        className="bg-blue-500 h-2 rounded"
                        style={{ width: `${(frequencyData.values[index] / Math.max(...frequencyData.values)) * 100}px` }}
                      ></div>
                      <span className="text-sm text-gray-600 w-16 text-right">
                        {frequencyData.values[index].toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Customer Lifetime Value Analysis */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Customer Lifetime Value Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-900">$127</div>
                <div className="text-sm text-gray-500 mt-1">Avg CLV</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">$183</div>
                <div className="text-sm text-gray-500 mt-1">High-Value CLV</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">18.3</div>
                <div className="text-sm text-gray-500 mt-1">Avg Months Retained</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600">12.4%</div>
                <div className="text-sm text-gray-500 mt-1">Churn Risk</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Customer Insights Table */}
        <Card>
          <CardHeader>
            <CardTitle>Customer Segment Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Segment</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customers</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Spend</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frequency</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Churn Risk</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CLV</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {segments.map((segment) => (
                    <tr key={segment.id}>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{segment.segmentName}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{segment.customerCount.toLocaleString()}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">${segment.avgSpend}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{segment.purchaseFrequency}x/quarter</td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`font-medium ${
                          segment.churnRiskPct < 10 ? 'text-green-600' : 
                          segment.churnRiskPct < 20 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {segment.churnRiskPct < 10 ? 'Low' : 
                           segment.churnRiskPct < 20 ? 'Medium' : 'High'} ({segment.churnRiskPct}%)
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-700">${segment.cltv}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
