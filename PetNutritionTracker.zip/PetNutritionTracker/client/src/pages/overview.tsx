import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { MetricCard } from "@/components/metric-card";
import { SalesTrendChart } from "@/components/charts/sales-trend-chart";
import { DistributionChart } from "@/components/charts/distribution-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GlobalFilters, defaultFilters, type GlobalFilters as FilterType } from "@/components/global-filters";
import { DollarSign, Package, Users, Tag } from "lucide-react";

export default function Overview() {
  const [filters, setFilters] = useState<FilterType>(defaultFilters);
  
  const { data: nutritionData, isLoading, refetch } = useQuery({
    queryKey: ["/api/nutrition-data", filters],
    queryFn: api.getNutritionData,
  });

  // Refetch data when filters change
  useEffect(() => {
    refetch();
  }, [filters, refetch]);

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  const data = nutritionData?.[0];

  if (!data) {
    return <div className="flex items-center justify-center h-screen">No data available</div>;
  }

  return (
    <div>
      <Header
        title="Performance Overview"
        subtitle="Q1 2025 Performance Dashboard"
        actionButton={{
          label: "Export Report",
          onClick: () => console.log("Export report")
        }}
      >
        <Select defaultValue="q1-2025">
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="q1-2025">Q1 2025</SelectItem>
            <SelectItem value="q4-2024">Q4 2024</SelectItem>
            <SelectItem value="q3-2024">Q3 2024</SelectItem>
          </SelectContent>
        </Select>
      </Header>

      <div className="p-8">
        {/* Global Filters */}
        <GlobalFilters 
          filters={filters} 
          onFiltersChange={setFilters} 
        />
        
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total Sales Value"
            value={`$${data.salesValue.toLocaleString()}`}
            change="+12.5%"
            changeType="positive"
            icon={<DollarSign className="text-green-600 text-lg" />}
            iconBgColor="bg-green-100"
          />
          <MetricCard
            title="Units Sold"
            value={data.salesUnits.toLocaleString()}
            change="+8.3%"
            changeType="positive"
            icon={<Package className="text-blue-600 text-lg" />}
            iconBgColor="bg-blue-100"
          />
          <MetricCard
            title="Customer Penetration"
            value={`${data.customerPenetrationPct}%`}
            change="-2.1%"
            changeType="negative"
            icon={<Users className="text-purple-600 text-lg" />}
            iconBgColor="bg-purple-100"
          />
          <MetricCard
            title="Avg Price per Unit"
            value={`$${data.averagePricePerUnit}`}
            change="+3.8%"
            changeType="positive"
            icon={<Tag className="text-yellow-600 text-lg" />}
            iconBgColor="bg-yellow-100"
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Sales Trend Chart */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Sales Trend</CardTitle>
              <Select defaultValue="12months">
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="12months">Last 12 months</SelectItem>
                  <SelectItem value="6months">Last 6 months</SelectItem>
                  <SelectItem value="3months">Last 3 months</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              <SalesTrendChart />
            </CardContent>
          </Card>

          {/* Distribution Performance */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Distribution Performance</CardTitle>
              <div className="text-sm text-gray-500">ACV Weighted ROS: {data.acvWeightedRosDistributionPct}%</div>
            </CardHeader>
            <CardContent>
              <DistributionChart distributionPct={data.acvWeightedRosDistributionPct} />
            </CardContent>
          </Card>
        </div>

        {/* Product Performance Table */}
        <Card>
          <CardHeader>
            <CardTitle>Product Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales Value</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Units</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Growth</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Market Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Pedigree Adult Complete</td>
                    <td className="px-6 py-4 text-sm text-gray-700">$89,200</td>
                    <td className="px-6 py-4 text-sm text-gray-700">4,460</td>
                    <td className="px-6 py-4 text-sm">
                      <span className="text-green-600 font-medium">+15.2%</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">53.1%</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Pedigree Puppy Complete</td>
                    <td className="px-6 py-4 text-sm text-gray-700">$47,800</td>
                    <td className="px-6 py-4 text-sm text-gray-700">2,390</td>
                    <td className="px-6 py-4 text-sm">
                      <span className="text-green-600 font-medium">+8.7%</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">28.5%</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Pedigree Senior Complete</td>
                    <td className="px-6 py-4 text-sm text-gray-700">$31,000</td>
                    <td className="px-6 py-4 text-sm text-gray-700">1,800</td>
                    <td className="px-6 py-4 text-sm">
                      <span className="text-red-600 font-medium">-2.3%</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">18.4%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
