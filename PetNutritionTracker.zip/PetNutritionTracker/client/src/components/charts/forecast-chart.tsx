import { useEffect, useRef } from "react";
import { Chart, ChartConfiguration } from "chart.js/auto";

interface ForecastChartProps {
  forecastData?: {
    labels: string[];
    actual: (number | null)[];
    forecast: (number | null)[];
    confidence: (number | null)[];
  };
}

export function ForecastChart({ forecastData }: ForecastChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const defaultData = {
      labels: ['Q1 2025', 'Q2 2025', 'Q3 2025', 'Q4 2025'],
      actual: [168000, null, null, null],
      forecast: [null, 185000, 198000, 215000],
      confidence: [null, 175000, 188000, 195000]
    };

    const data = forecastData || defaultData;

    const config: ChartConfiguration = {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [
          {
            label: 'Actual',
            data: data.actual,
            borderColor: 'hsl(207, 90%, 54%)',
            backgroundColor: 'hsl(207, 90%, 54%)',
            pointBackgroundColor: 'hsl(207, 90%, 54%)'
          },
          {
            label: 'Forecast',
            data: data.forecast,
            borderColor: 'hsl(142, 76%, 36%)',
            backgroundColor: 'hsl(142, 76%, 36%)',
            borderDash: [5, 5],
            pointBackgroundColor: 'hsl(142, 76%, 36%)'
          },
          {
            label: 'Confidence Interval',
            data: data.confidence,
            borderColor: 'hsl(20, 5.9%, 90%)',
            backgroundColor: 'hsla(20, 5.9%, 90%, 0.2)',
            fill: '+1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          }
        },
        scales: {
          y: {
            beginAtZero: false,
            ticks: {
              callback: function(value) {
                return '$' + (Number(value) / 1000) + 'K';
              }
            }
          }
        }
      }
    };

    chartRef.current = new Chart(canvasRef.current, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [forecastData]);

  return (
    <div className="relative h-[300px]">
      <canvas ref={canvasRef}></canvas>
    </div>
  );
}
