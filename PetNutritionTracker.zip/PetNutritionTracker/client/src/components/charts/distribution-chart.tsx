import { useEffect, useRef } from "react";
import { Chart, ChartConfiguration } from "chart.js/auto";

interface DistributionChartProps {
  distributionPct?: number;
}

export function DistributionChart({ distributionPct = 78.5 }: DistributionChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const config: ChartConfiguration = {
      type: 'doughnut',
      data: {
        labels: ['Active Stores', 'Available Stores'],
        datasets: [{
          data: [distributionPct, 100 - distributionPct],
          backgroundColor: ['hsl(207, 90%, 54%)', 'hsl(20, 5.9%, 90%)'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    };

    chartRef.current = new Chart(canvasRef.current, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [distributionPct]);

  return (
    <div className="relative h-[300px]">
      <canvas ref={canvasRef}></canvas>
    </div>
  );
}
