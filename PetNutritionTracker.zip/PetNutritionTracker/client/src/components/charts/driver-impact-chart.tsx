import { useEffect, useRef } from "react";
import { Chart, ChartConfiguration } from "chart.js/auto";

interface DriverImpactChartProps {
  simulationData?: {
    priceChange: number;
    distributionChange: number;
    marketingSpendChange: number;
    incrementalRevenue: number;
  };
}

export function DriverImpactChart({ simulationData }: DriverImpactChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    if (!simulationData) {
      // Show placeholder if no simulation data
      return;
    }

    // Calculate individual impact contributions
    const baselineRevenue = 168000; // Current baseline from sample data
    const priceImpact = (simulationData.priceChange / 100) * baselineRevenue * -0.8; // Price elasticity
    const distributionImpact = (simulationData.distributionChange / 100) * baselineRevenue * 0.6;
    const marketingImpact = (simulationData.marketingSpendChange / 100) * baselineRevenue * 0.3;

    const impacts = [
      { label: 'Price Change', value: Math.round(priceImpact) },
      { label: 'Distribution', value: Math.round(distributionImpact) },
      { label: 'Marketing', value: Math.round(marketingImpact) }
    ].filter(item => Math.abs(item.value) > 100); // Only show meaningful impacts

    if (impacts.length === 0) {
      return;
    }

    const config: ChartConfiguration = {
      type: 'bar',
      data: {
        labels: impacts.map(item => item.label),
        datasets: [{
          label: 'Revenue Impact ($)',
          data: impacts.map(item => item.value),
          backgroundColor: impacts.map(item => 
            item.value > 0 ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)'
          ),
          borderColor: impacts.map(item => 
            item.value > 0 ? 'hsl(142, 76%, 26%)' : 'hsl(0, 84%, 50%)'
          ),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const value = context.parsed.y;
                const prefix = value > 0 ? '+' : '';
                return `${prefix}$${Math.abs(value).toLocaleString()}`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                const num = Number(value);
                const prefix = num > 0 ? '+' : '';
                return prefix + '$' + (Math.abs(num) / 1000) + 'K';
              }
            },
            grid: {
              color: 'hsl(20, 5.9%, 90%)'
            }
          },
          x: {
            grid: {
              display: false
            }
          }
        }
      }
    };

    chartRef.current = new Chart(canvasRef.current, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [simulationData]);

  if (!simulationData) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500 border border-gray-200 rounded-lg bg-gray-50">
        <div className="text-center">
          <div className="text-lg font-medium mb-2">No Simulation Data</div>
          <div className="text-sm">Run a simulation to see driver impact analysis</div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-[300px]">
      <canvas ref={canvasRef}></canvas>
    </div>
  );
}