import { useEffect, useRef } from "react";
import { Chart, ChartConfiguration } from "chart.js/auto";

interface CustomerSegmentChartProps {
  segments?: Array<{
    name: string;
    percentage: number;
  }>;
}

export function CustomerSegmentChart({ segments }: CustomerSegmentChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const defaultSegments = [
      { name: 'High-Value', percentage: 15 },
      { name: 'Loyal', percentage: 9.2 },
      { name: 'Regular', percentage: 50.1 },
      { name: 'At-Risk', percentage: 25.7 }
    ];

    const data = segments || defaultSegments;

    const config: ChartConfiguration = {
      type: 'pie',
      data: {
        labels: data.map(s => s.name),
        datasets: [{
          data: data.map(s => s.percentage),
          backgroundColor: [
            'hsl(142, 76%, 36%)', // green for high-value
            'hsl(207, 90%, 54%)', // blue for loyal
            'hsl(43, 96%, 56%)',  // yellow for regular
            'hsl(0, 84%, 60%)'    // red for at-risk
          ]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    };

    chartRef.current = new Chart(canvasRef.current, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [segments]);

  return (
    <div className="relative h-[300px]">
      <canvas ref={canvasRef}></canvas>
    </div>
  );
}
