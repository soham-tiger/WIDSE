import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { Link } from "wouter";

const navigationItems = [
  {
    href: "/",
    label: "Overview",
    icon: "fas fa-chart-line",
    page: "overview"
  },
  {
    href: "/drivers",
    label: "Sales Drivers",
    icon: "fas fa-sliders-h",
    page: "drivers"
  },
  {
    href: "/customers",
    label: "Customers",
    icon: "fas fa-users",
    page: "customers"
  },
  {
    href: "/insights",
    label: "AI Insights",
    icon: "fas fa-brain",
    page: "insights"
  }
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-80 bg-white shadow-lg border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <i className="fas fa-paw text-white text-lg"></i>
          </div>
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Pet Nutrition Analytics</h1>
            <p className="text-sm text-gray-500">Pedigree Brand Dashboard</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const isActive = location === item.href;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg font-medium transition-colors",
                    isActive
                      ? "text-blue-600 bg-blue-50"
                      : "text-gray-700 hover:text-blue-600 hover:bg-blue-50"
                  )}
                >
                  <i className={cn(item.icon, "mr-3")}></i>
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>Last updated: 2 min ago</span>
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
        </div>
      </div>
    </aside>
  );
}
