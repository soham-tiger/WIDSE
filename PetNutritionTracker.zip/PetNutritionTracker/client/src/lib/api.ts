import { apiRequest } from "./queryClient";

export const api = {
  // Nutrition Data
  getNutritionData: () => fetch("/api/nutrition-data").then(res => res.json()),
  getNutritionDataByUpc: (upc: string) => fetch(`/api/nutrition-data/${upc}`).then(res => res.json()),

  // Forecast
  generateForecast: (data: any) => apiRequest("POST", "/api/forecast", data).then(res => res.json()),
  getForecast: (upc?: string) => {
    const url = upc ? `/api/forecast?upc=${upc}` : "/api/forecast";
    return fetch(url).then(res => res.json());
  },

  // Simulation
  runSimulation: (data: any) => apiRequest("POST", "/api/simulate", data).then(res => res.json()),
  getSimulations: () => fetch("/api/simulations").then(res => res.json()),

  // Customer Segments
  getCustomerSegments: () => fetch("/api/customer-segments").then(res => res.json()),

  // Insights
  generateInsights: () => apiRequest("POST", "/api/insights/generate").then(res => res.json()),
  getInsights: (type?: string) => {
    const url = type ? `/api/insights?type=${type}` : "/api/insights";
    return fetch(url).then(res => res.json());
  },

  // Chat
  askQuestion: (question: string) => apiRequest("POST", "/api/chat", { question }).then(res => res.json()),
};
