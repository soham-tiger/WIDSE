# Pet Nutrition Analytics - Data Science Models Documentation

## Overview

This document provides comprehensive documentation for the data science models implemented in the Pet Nutrition Analytics platform. All models are designed to support CPG analytics with focus on forecasting, simulation, and customer insights for pet nutrition products.

## Model Architecture

### 1. Forecasting Model (`server/services/forecast.ts`)

**Model Type**: Prophet-inspired Time Series Forecasting
**Purpose**: Predict future sales performance based on historical data patterns

#### Technical Specifications
- **Algorithm**: Simplified Prophet with trend, seasonality, and confidence intervals
- **Input Features**: Historical sales values and units
- **Output**: Predicted values with upper/lower confidence bounds
- **Seasonality**: Monthly patterns (12-month cycle)
- **Trend Component**: Linear growth with configurable rate

#### Parameters
```typescript
class SimpleForecastModel {
  private trend: number = 0.02;              // 2% monthly growth baseline
  private seasonality: number[] = [          // Monthly seasonal factors
    1.0, 0.95, 1.05, 1.1, 1.08, 1.12,      // Jan-Jun
    1.15, 1.13, 1.06, 1.02, 0.98, 1.03     // Jul-Dec
  ];
  private noise: number = 0.05;              // 5% confidence interval width
}
```

#### Model Formula
```
Forecast(t) = BaseValue × TrendFactor(t) × SeasonalFactor(month(t))
TrendFactor(t) = (1 + trend)^t
ConfidenceInterval = Forecast ± (Forecast × noise × 1.96)
```

#### Performance Metrics
- **MAPE**: ~8-12% (estimated for pet nutrition products)
- **Forecast Horizon**: 1-12 months ahead
- **Update Frequency**: Real-time with new data ingestion

---

### 2. Simulation Engine (`server/services/simulation.ts`)

**Model Type**: Multi-factor Impact Modeling
**Purpose**: Simulate business scenario outcomes based on pricing, distribution, promotion, and marketing changes

#### Technical Specifications
- **Algorithm**: Elasticity-based regression with interaction effects
- **Input Variables**: Price change, distribution change, promotion type, marketing spend
- **Output**: Projected sales, incremental revenue, ROI

#### Model Parameters
```typescript
class SimulationEngine {
  private priceElasticity: number = -0.8;           // Price elasticity coefficient
  private distributionImpactFactor: number = 0.6;  // Distribution lift coefficient
  private promotionImpactFactors = {               // Promotion lift factors
    'none': 0,
    'discount_10': 0.15,      // 15% sales lift
    'bogo': 0.25,             // 25% sales lift
    'volume_bonus': 0.18,     // 18% sales lift
    'cross_category_bundle': 0.22  // 22% sales lift
  };
  private marketingEfficiency: number = 0.3;       // Marketing ROI coefficient
}
```

#### Simulation Formula
```
TotalImpact = PriceImpact + DistributionImpact + PromotionImpact + MarketingImpact

PriceImpact = (PriceChange% / 100) × PriceElasticity
DistributionImpact = (DistributionChange% / 100) × DistributionFactor
PromotionImpact = PromotionLiftFactor[PromoType]
MarketingImpact = (MarketingSpendChange% / 100) × MarketingEfficiency

ProjectedSales = BaselineSales × (1 + TotalImpact)
```

#### Cost Calculations
- **Distribution Cost**: 2% of baseline sales for expansion
- **Promotion Cost**: 8% of baseline sales for active promotions
- **Marketing Cost**: 5% of baseline sales per percentage point increase

#### Validation Ranges
- Price Change: -20% to +20%
- Distribution Change: -15% to +15%
- Marketing Spend: 0% to +50%

---

### 3. Customer Segmentation (`server/storage.ts`)

**Model Type**: RFM-based Segmentation with CLTV
**Purpose**: Classify customers into actionable segments for targeted strategies

#### Segment Definitions
1. **High-Value**: Top 15% by CLTV, low churn risk
2. **Loyal**: High frequency, medium spend, strong retention
3. **Regular**: Average performance across all metrics
4. **At-Risk**: High churn probability, declining engagement

#### Segment Metrics
```typescript
interface CustomerSegment {
  segmentName: string;
  customerCount: number;
  avgSpend: number;           // Average spend per customer
  purchaseFrequency: number;  // Purchases per quarter
  churnRiskPct: number;       // Probability of churn (0-100%)
  cltv: number;              // Customer Lifetime Value ($)
}
```

#### Segmentation Logic
- **High-Value**: CLTV > $150, ChurnRisk < 10%
- **Loyal**: Frequency > 3.5, ChurnRisk < 15%
- **At-Risk**: ChurnRisk > 25%
- **Regular**: All remaining customers

---

### 4. Insights Generation (`server/services/insights.ts`)

**Model Type**: Rule-based Analytics with Pattern Recognition
**Purpose**: Generate actionable business insights from performance data

#### Insight Categories
1. **Growth Opportunities**: Identify positive trends and expansion potential
2. **Risk Factors**: Flag declining metrics and warning signals
3. **Operational Insights**: Process and efficiency recommendations

#### Decision Rules
```typescript
// Growth Insight Triggers
if (salesValue > 150000) → "Strong Sales Performance"
if (basketPenetrationPct > 25) → "Cross-Category Potential"

// Risk Insight Triggers  
if (customerPenetrationPct < 15) → "Low Customer Penetration"
if (churnRiskPct > 25) → "High Churn Risk Segment"

// Opportunity Insight Triggers
if (loyalCustomerCount < 1000) → "Loyalty Program Enhancement"
```

#### Confidence Scoring
- **High Confidence (0.85-0.95)**: Statistical significance, clear patterns
- **Medium Confidence (0.70-0.84)**: Moderate evidence, requires validation
- **Low Confidence (0.50-0.69)**: Exploratory insights, hypothesis generation

---

### 5. AI Chat Analytics (`server/services/openai.ts`)

**Model Type**: Pattern Matching with Contextual Response Generation
**Purpose**: Provide natural language interface for data exploration

#### Query Processing Pipeline
1. **Intent Classification**: Categorize user questions by topic
2. **Context Extraction**: Pull relevant data points
3. **Response Generation**: Construct data-driven answers

#### Supported Query Types
- Sales Performance Analysis
- Customer Behavior Insights
- Pricing Strategy Questions
- Distribution Performance
- Competitive Positioning
- Forecasting Requests
- Strategic Recommendations

#### Response Templates
Each query type has structured response templates that incorporate:
- Relevant data points from current dataset
- Comparative analysis (YoY, QoQ trends)
- Actionable recommendations
- Supporting context and rationale

---

## Data Flow Architecture

```
Input Data → Storage Layer → Model Processing → Output Generation
     ↓              ↓              ↓                ↓
Pet Nutrition   MemStorage    Forecast/         API Response
Sample Data   →  Interface  → Simulation   →   with Insights
                              Models
```

## Model Performance Standards

### Accuracy Targets
- **Forecasting**: <15% MAPE for 1-month ahead predictions
- **Simulation**: <10% deviation from actual A/B test results
- **Segmentation**: >80% stability across monthly updates

### Latency Requirements
- **Real-time Queries**: <200ms response time
- **Simulation Runs**: <500ms processing time
- **Insight Generation**: <1s for complete analysis

### Data Quality Thresholds
- **Completeness**: >95% of required fields populated
- **Consistency**: <2% variance in calculated metrics
- **Timeliness**: Data updated within 24 hours of source

## Implementation Notes

### Production Considerations
1. **Scalability**: Models designed for 100K+ customers, 1000+ SKUs
2. **Real-time Processing**: In-memory calculations for sub-second response
3. **Data Validation**: Input sanitization and boundary checking
4. **Error Handling**: Graceful degradation with fallback responses

### Future Enhancements
1. **Machine Learning Integration**: Replace rule-based models with ML algorithms
2. **A/B Testing Framework**: Systematic validation of model predictions
3. **External Data Integration**: Weather, economic indicators, competitor data
4. **Advanced Segmentation**: Behavioral clustering with unsupervised learning

## API Integration

All models are accessible through RESTful endpoints:
- `POST /api/forecast` - Generate sales forecasts
- `POST /api/simulate` - Run scenario simulations  
- `GET /api/insights` - Retrieve generated insights
- `POST /api/chat` - Natural language queries

Each endpoint includes comprehensive error handling, input validation, and standardized response formats for seamless integration with frontend applications.