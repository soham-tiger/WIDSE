# Pet Nutrition Analytics - API Integration Guide

## Overview

This guide provides comprehensive documentation for integrating with the Pet Nutrition Analytics API. The API follows RESTful principles and returns JSON responses for all endpoints.

## Base Configuration

- **Base URL**: `http://localhost:5000/api` (development)
- **Content-Type**: `application/json`
- **Response Format**: JSON
- **Error Handling**: Standard HTTP status codes

## Authentication

Currently, no authentication is required for API access in development mode.

## Endpoints Reference

### 1. Pet Nutrition Data

#### Get All Nutrition Data
```http
GET /api/nutrition-data
```

**Response Example:**
```json
[
  {
    "id": 1,
    "upc": "12345",
    "reportStartDate": "2025-01-01",
    "reportEndDate": "2025-03-31",
    "acvWeightedRosDistributionPct": 78.5,
    "acvWeightedRosSales": 152000,
    "acvWeightedRosUnits": 8450,
    "salesValue": 168000,
    "salesUnits": 8650,
    "customerPenetrationPct": 13.6,
    "loyalPenetrationPct": 9.2,
    "averagePricePerUnit": 4.9
  }
]
```

#### Get Nutrition Data by UPC
```http
GET /api/nutrition-data/{upc}
```

**Parameters:**
- `upc` (string): Product UPC code

---

### 2. Forecasting

#### Generate Forecast
```http
POST /api/forecast
```

**Request Body:**
```json
{
  "upc": "12345",
  "dateRange": {
    "start": "2025-01-01",
    "end": "2025-03-31"
  },
  "periods": 4
}
```

**Response Example:**
```json
[
  {
    "id": 1,
    "upc": "12345",
    "forecastDate": "2025-04-01",
    "predictedSalesValue": 185000,
    "predictedSalesUnits": 9100,
    "confidenceLower": 175000,
    "confidenceUpper": 195000,
    "createdAt": "2025-07-05T07:12:10.000Z"
  }
]
```

#### Get Forecast Results
```http
GET /api/forecast?upc={upc}
```

**Query Parameters:**
- `upc` (optional): Filter by specific UPC

---

### 3. Scenario Simulation

#### Run Simulation
```http
POST /api/simulate
```

**Request Body:**
```json
{
  "priceChange": -5,
  "distributionChange": 10,
  "promotionType": "discount_10",
  "marketingSpendChange": 25
}
```

**Valid Values:**
- `priceChange`: -20 to 20 (percentage)
- `distributionChange`: -15 to 15 (percentage)
- `promotionType`: "none", "discount_10", "bogo", "volume_bonus", "cross_category_bundle"
- `marketingSpendChange`: 0 to 50 (percentage)

**Response Example:**
```json
{
  "id": 1,
  "scenarioName": "Simulation_1751699530123",
  "priceChange": -5,
  "distributionChange": 10,
  "promotionType": "discount_10",
  "marketingSpendChange": 25,
  "projectedSalesValue": 195000,
  "projectedSalesUnits": 9750,
  "incrementalRevenue": 27000,
  "roi": 2.3,
  "createdAt": "2025-07-05T07:12:10.000Z"
}
```

#### Get Simulation History
```http
GET /api/simulations
```

---

### 4. Customer Segments

#### Get Customer Segments
```http
GET /api/customer-segments
```

**Response Example:**
```json
[
  {
    "id": 1,
    "segmentName": "High-Value",
    "customerCount": 1320,
    "avgSpend": 43.20,
    "purchaseFrequency": 4.2,
    "churnRiskPct": 5.2,
    "cltv": 183
  },
  {
    "id": 2,
    "segmentName": "Loyal",
    "customerCount": 809,
    "avgSpend": 27.30,
    "purchaseFrequency": 3.8,
    "churnRiskPct": 8.1,
    "cltv": 156
  }
]
```

---

### 5. AI Insights

#### Generate New Insights
```http
POST /api/insights/generate
```

**Response Example:**
```json
[
  {
    "id": 1,
    "type": "growth",
    "title": "Strong Sales Performance",
    "description": "Sales value of $168,000 indicates strong market performance...",
    "recommendation": "Expand distribution to capitalize on momentum",
    "confidence": 0.9,
    "createdAt": "2025-07-05T07:12:10.000Z"
  }
]
```

#### Get Insights
```http
GET /api/insights?type={type}
```

**Query Parameters:**
- `type` (optional): Filter by insight type ("growth", "risk", "opportunity")

---

### 6. AI Chat

#### Ask Question
```http
POST /api/chat
```

**Request Body:**
```json
{
  "question": "Why did customer penetration decline?"
}
```

**Response Example:**
```json
{
  "answer": "Customer penetration at 13.6% declined 2.1% this quarter, primarily due to increased competitive pressure and market saturation in key demographics..."
}
```

## Error Handling

### Standard HTTP Status Codes

- `200` - Success
- `400` - Bad Request (validation errors)
- `404` - Resource Not Found
- `500` - Internal Server Error

### Error Response Format
```json
{
  "message": "Error description",
  "error": "Additional error details (development only)"
}
```

## Integration Examples

### JavaScript/TypeScript (React)
```typescript
// Using fetch API
const runSimulation = async (params: SimulationRequest) => {
  try {
    const response = await fetch('/api/simulate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    
    if (!response.ok) {
      throw new Error('Simulation failed');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Using React Query
const { data, mutate } = useMutation({
  mutationFn: (params) => fetch('/api/simulate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  }).then(res => res.json()),
  onSuccess: (data) => {
    console.log('Simulation result:', data);
  },
});
```

### Python Integration
```python
import requests
import json

class PetNutritionAPI:
    def __init__(self, base_url="http://localhost:5000/api"):
        self.base_url = base_url
    
    def run_simulation(self, price_change, distribution_change, 
                      promotion_type, marketing_spend_change):
        payload = {
            "priceChange": price_change,
            "distributionChange": distribution_change,
            "promotionType": promotion_type,
            "marketingSpendChange": marketing_spend_change
        }
        
        response = requests.post(
            f"{self.base_url}/simulate",
            headers={"Content-Type": "application/json"},
            data=json.dumps(payload)
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"API Error: {response.status_code}")
    
    def get_insights(self, insight_type=None):
        url = f"{self.base_url}/insights"
        if insight_type:
            url += f"?type={insight_type}"
        
        response = requests.get(url)
        return response.json()

# Usage example
api = PetNutritionAPI()
result = api.run_simulation(
    price_change=-5,
    distribution_change=10,
    promotion_type="discount_10",
    marketing_spend_change=25
)
print(f"Projected sales: ${result['projectedSalesValue']:,}")
```

## Rate Limiting

Currently no rate limiting is implemented. In production, consider:
- 100 requests per minute per IP
- 1000 requests per hour per user
- Special limits for compute-intensive operations (simulations, insights)

## Data Validation

All endpoints validate input data using Zod schemas:

### Simulation Request Validation
```typescript
{
  priceChange: z.number().min(-20).max(20),
  distributionChange: z.number().min(-15).max(15),
  promotionType: z.enum(['none', 'discount_10', 'bogo', 'volume_bonus', 'cross_category_bundle']),
  marketingSpendChange: z.number().min(0).max(50)
}
```

### Forecast Request Validation
```typescript
{
  upc: z.string(),
  dateRange: {
    start: z.string(),
    end: z.string()
  },
  periods: z.number().default(4)
}
```

## Performance Considerations

- **Response Times**: Most endpoints respond in <200ms
- **Simulation Processing**: Complex scenarios may take up to 500ms
- **Caching**: Results are stored in memory for session duration
- **Concurrent Requests**: No current limitations on concurrent API calls

## Testing

### Test Data
The system includes comprehensive test data:
- Sample pet nutrition metrics for UPC "12345"
- Pre-defined customer segments (High-Value, Loyal, Regular, At-Risk)
- Baseline performance metrics for simulation comparisons

### Sample Test Scenarios
1. **Price Sensitivity Test**: Run simulations with price changes from -10% to +10%
2. **Distribution Impact**: Test distribution changes across different regions
3. **Promotion Effectiveness**: Compare different promotion types
4. **Insights Generation**: Validate insight triggers with known data patterns

This API provides a robust foundation for building data-driven pet nutrition analytics applications with real-time simulation and AI-powered insights capabilities.